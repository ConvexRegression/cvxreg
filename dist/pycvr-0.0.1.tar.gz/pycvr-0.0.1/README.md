pyCVR is a Python-embedded modeling language for convex regression.

"""
Machine Learning module for Convex Regression
=============================================

This module contains the machine learning methods for Convex Regression.
"""

import sys

__all__ = ['ConvexRegression']